# CONTENT OF FOLDER Scripts updated vie ene 29 11:41:16 CET 2021

To obtain help of any script run it with -h or -help
